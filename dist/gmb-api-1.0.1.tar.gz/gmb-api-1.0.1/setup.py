# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gmb_api']

package_data = \
{'': ['*']}

install_requires = \
['google-auth-oauthlib>=0.4.4,<0.5.0',
 'oauth2client>=4.1.3,<5.0.0',
 'pydantic>=1.8.2,<2.0.0']

setup_kwargs = {
    'name': 'gmb-api',
    'version': '1.0.1',
    'description': '',
    'long_description': None,
    'author': 'bradi',
    'author_email': 'bradisbon@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
